package com.example.practise;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    RadioGroup g1, g2, g3, g4, g5;
    Button btnSubmit;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        g1 = findViewById(R.id.group1);
        g2 = findViewById(R.id.group2);
        g3 = findViewById(R.id.group3);
        g4 = findViewById(R.id.group4);
        g5 = findViewById(R.id.group5);
        btnSubmit = findViewById(R.id.btnSubmit);
        result = findViewById(R.id.result);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int score = 0;

                // Correct Answers
                if (g1.getCheckedRadioButtonId() == R.id.q1c) score++;
                if (g2.getCheckedRadioButtonId() == R.id.q2a) score++;
                if (g3.getCheckedRadioButtonId() == R.id.q3c) score++;
                if (g4.getCheckedRadioButtonId() == R.id.q4c) score++;
                if (g5.getCheckedRadioButtonId() == R.id.q5c) score++;

                result.setText("Your Score: " + score + " / 5");

                if (score == 5)
                    Toast.makeText(MainActivity.this, "Excellent! Perfect score 🎯", Toast.LENGTH_LONG).show();
                else if (score >= 3)
                    Toast.makeText(MainActivity.this, "Good job 👍", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(MainActivity.this, "Keep practicing 💪", Toast.LENGTH_LONG).show();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
