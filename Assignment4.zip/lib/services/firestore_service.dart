
import '../models/task_model.dart';

class FirestoreService {
  void addTask(Task task) {
    // Firebase logic goes here
  }
}
