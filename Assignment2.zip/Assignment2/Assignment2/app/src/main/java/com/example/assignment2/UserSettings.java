package com.example.assignment2;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.SharedMemory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class UserSettings extends Fragment {

    private EditText userName,password,email,themeColor;
    private CheckBox checkboxNotification;

    public UserSettings() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_user_settings, container, false);
        userName = view.findViewById(R.id.userName);
        email = view.findViewById(R.id.email);
        password = view.findViewById(R.id.password);
        themeColor = view.findViewById(R.id.themeColor);
        checkboxNotification = view.findViewById(R.id.checkboxNotification);
        Button btnSave = view.findViewById(R.id.btnSave);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if(userName.getText().toString().isEmpty())
                {
                    Toast.makeText(requireActivity(),"User Name can not be empty",Toast.LENGTH_LONG).show();
                    return;
                }
                if(!email.getText().toString().contains("@"))
                {
                    Toast.makeText(requireActivity(),"Enter a valid email",Toast.LENGTH_LONG).show();
                    return;
                }
                if(password.getText().toString().length()<4)
                {
                    Toast.makeText(requireActivity(), "Password must be at least 4 characters", Toast.LENGTH_SHORT).show();
                    return;
                }
                SharedPreferences sp = requireActivity().getSharedPreferences("UserPrefs",Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("UserName",userName.getText().toString());
                editor.putString("email",email.getText().toString());
                editor.putString("password",password.getText().toString());
                editor.putString("themeColor",themeColor.getText().toString());
                editor.putBoolean("notifications",checkboxNotification.isChecked());
                editor.apply();
            }
        });
        return view;
    }
}