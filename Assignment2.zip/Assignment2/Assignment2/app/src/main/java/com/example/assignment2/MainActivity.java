package com.example.assignment2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity {

    Button userSetting,profileView;
    boolean isFragmentAdded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        userSetting = findViewById(R.id.userSetting);
        profileView = findViewById(R.id.profileView);

        userSetting.setOnClickListener(new View.OnClickListener()
        {
           @Override
           public void onClick(View view)
           {
               FragmentManager fm = getSupportFragmentManager();
               FragmentTransaction ft = fm.beginTransaction();

               if(!isFragmentAdded)
               {
                   ft.add(R.id.frameLayout, new UserSettings());
                   isFragmentAdded = true;
               }
               else
               {
                   ft.replace(R.id.frameLayout,new UserSettings());
               }
               ft.commit();
           }
        });

        profileView.setOnClickListener(new View.OnClickListener()
        {
           @Override
           public void onClick(View view)
           {
               FragmentManager fm = getSupportFragmentManager();
               FragmentTransaction ft = fm.beginTransaction();

               if(!isFragmentAdded)
               {
                   ft.add(R.id.frameLayout, new ProfileView());
                   isFragmentAdded = true;
               }
               else
               {
                   ft.replace(R.id.frameLayout,new ProfileView());
               }
               ft.commit();
           }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}