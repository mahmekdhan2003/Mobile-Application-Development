package com.example.assignment2;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

public class ProfileView extends Fragment {

    public ProfileView() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_profile_view, container, false);
        RelativeLayout rel = view.findViewById(R.id.rel1);
        TextView name = view.findViewById(R.id.Username);
        TextView email = view.findViewById(R.id.Email);
        TextView password = view.findViewById(R.id.Password);
        TextView color = view.findViewById(R.id.ThemeColor);
        TextView notifications = view.findViewById(R.id.Notification);

        SharedPreferences sp = requireActivity().getSharedPreferences("UserPrefs",Context.MODE_PRIVATE);
        String Name = sp.getString("UserName","");
        String Email = sp.getString("email","");
        String Password = sp.getString("password","");
        String Color = sp.getString("themeColor","");
        Boolean Notifications = sp.getBoolean("notifications",false);

        name.setText("User Name: "+Name);
        email.setText("Email: "+Email);
        password.setText("Password: "+Password);
        color.setText("Theme Color: "+Color);
        notifications.setText("Notifications: "+ (Notifications ? "Enables" : "Disabled"));

        if (Color.equalsIgnoreCase("light"))
        {
            rel.setBackgroundColor(android.graphics.Color.YELLOW);
        }
        else if (Color.equalsIgnoreCase("dark"))
        {
            rel.setBackgroundColor(android.graphics.Color.CYAN);
        }


        return view;
    }
}