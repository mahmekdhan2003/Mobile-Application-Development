package com.example.calculator;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private TextView display;
    private String currentNumber = "";
    private double result = 0.0;
    private String operation = "";
    private String history = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.textview);

        Button btn0 = findViewById(R.id.btn18);
        Button btn1 = findViewById(R.id.btn13);
        Button btn2 = findViewById(R.id.btn14);
        Button btn3 = findViewById(R.id.btn15);
        Button btn4 = findViewById(R.id.btn9);
        Button btn5 = findViewById(R.id.btn10);
        Button btn6 = findViewById(R.id.btn11);
        Button btn7 = findViewById(R.id.btn5);
        Button btn8 = findViewById(R.id.btn6);
        Button btn9 = findViewById(R.id.btn7);
        Button btnAC = findViewById(R.id.btn1);
        Button btnPlusMinus = findViewById(R.id.btn2);
        Button btnPercent = findViewById(R.id.btn3);
        Button btnDivide = findViewById(R.id.btn4);
        Button btnMultiply = findViewById(R.id.btn8);
        Button btnMinus = findViewById(R.id.btn12);
        Button btnPlus = findViewById(R.id.btn16);
        Button btnEquals = findViewById(R.id.btn20);
        Button btnDot = findViewById(R.id.btn19);
        Button btnH = findViewById(R.id.btn17);

        btn0.setOnClickListener(v -> {
            currentNumber += "0";
            display.setText(currentNumber);
        });

        btn1.setOnClickListener(v -> {
            currentNumber += "1";
            display.setText(currentNumber);
        });

        btn2.setOnClickListener(v -> {
            currentNumber += "2";
            display.setText(currentNumber);
        });

        btn3.setOnClickListener(v -> {
            currentNumber += "3";
            display.setText(currentNumber);
        });

        btn4.setOnClickListener(v -> {
            currentNumber += "4";
            display.setText(currentNumber);
        });

        btn5.setOnClickListener(v -> {
            currentNumber += "5";
            display.setText(currentNumber);
        });

        btn6.setOnClickListener(v -> {
            currentNumber += "6";
            display.setText(currentNumber);
        });

        btn7.setOnClickListener(v -> {
            currentNumber += "7";
            display.setText(currentNumber);
        });

        btn8.setOnClickListener(v -> {
            currentNumber += "8";
            display.setText(currentNumber);
        });

        btn9.setOnClickListener(v -> {
            currentNumber += "9";
            display.setText(currentNumber);
        });

        btnPlus.setOnClickListener(v -> {
            if (!currentNumber.isEmpty()) {
                if (operation.isEmpty()) {
                    result = Double.parseDouble(currentNumber);
                    history += currentNumber;
                } else {
                    double previousResult = result;
                    switch (operation) {
                        case "+":
                            result += Double.parseDouble(currentNumber);
                            history += " + " + currentNumber;
                            break;
                        case "-":
                            result -= Double.parseDouble(currentNumber);
                            history += " - " + currentNumber;
                            break;
                        case "*":
                            result *= Double.parseDouble(currentNumber);
                            history += " × " + currentNumber;
                            break;
                        case "/":
                            if (Double.parseDouble(currentNumber) != 0.0) {
                                result /= Double.parseDouble(currentNumber);
                                history += " ÷ " + currentNumber;
                            } else {
                                display.setText("Error");
                                return;
                            }
                            break;
                    }
                }
                operation = "+";
                currentNumber = "";
                display.setText(result % 1.0 == 0.0 ? String.valueOf((int) result) : String.valueOf(result));
            }
        });

        btnMinus.setOnClickListener(v -> {
            if (!currentNumber.isEmpty()) {
                if (operation.isEmpty()) {
                    result = Double.parseDouble(currentNumber);
                    history += currentNumber;
                } else {
                    switch (operation) {
                        case "+":
                            result += Double.parseDouble(currentNumber);
                            history += " + " + currentNumber;
                            break;
                        case "-":
                            result -= Double.parseDouble(currentNumber);
                            history += " - " + currentNumber;
                            break;
                        case "*":
                            result *= Double.parseDouble(currentNumber);
                            history += " × " + currentNumber;
                            break;
                        case "/":
                            if (Double.parseDouble(currentNumber) != 0.0) {
                                result /= Double.parseDouble(currentNumber);
                                history += " ÷ " + currentNumber;
                            } else {
                                display.setText("Error");
                                return;
                            }
                            break;
                    }
                }
                operation = "-";
                currentNumber = "";
                display.setText(result % 1.0 == 0.0 ? String.valueOf((int) result) : String.valueOf(result));
            }
        });

        btnMultiply.setOnClickListener(v -> {
            if (!currentNumber.isEmpty()) {
                if (operation.isEmpty()) {
                    result = Double.parseDouble(currentNumber);
                    history += currentNumber;
                } else {
                    switch (operation) {
                        case "+":
                            result += Double.parseDouble(currentNumber);
                            history += " + " + currentNumber;
                            break;
                        case "-":
                            result -= Double.parseDouble(currentNumber);
                            history += " - " + currentNumber;
                            break;
                        case "*":
                            result *= Double.parseDouble(currentNumber);
                            history += " × " + currentNumber;
                            break;
                        case "/":
                            if (Double.parseDouble(currentNumber) != 0.0) {
                                result /= Double.parseDouble(currentNumber);
                                history += " ÷ " + currentNumber;
                            } else {
                                display.setText("Error");
                                return;
                            }
                            break;
                    }
                }
                operation = "*";
                currentNumber = "";
                display.setText(result % 1.0 == 0.0 ? String.valueOf((int) result) : String.valueOf(result));
            }
        });

        btnDivide.setOnClickListener(v -> {
            if (!currentNumber.isEmpty()) {
                if (operation.isEmpty()) {
                    result = Double.parseDouble(currentNumber);
                    history += currentNumber;
                } else {
                    switch (operation) {
                        case "+":
                            result += Double.parseDouble(currentNumber);
                            history += " + " + currentNumber;
                            break;
                        case "-":
                            result -= Double.parseDouble(currentNumber);
                            history += " - " + currentNumber;
                            break;
                        case "*":
                            result *= Double.parseDouble(currentNumber);
                            history += " × " + currentNumber;
                            break;
                        case "/":
                            if (Double.parseDouble(currentNumber) != 0.0) {
                                result /= Double.parseDouble(currentNumber);
                                history += " ÷ " + currentNumber;
                            } else {
                                display.setText("Error");
                                return;
                            }
                            break;
                    }
                }
                operation = "/";
                currentNumber = "";
                display.setText(result % 1.0 == 0.0 ? String.valueOf((int) result) : String.valueOf(result));
            }
        });

        btnEquals.setOnClickListener(v -> {
            if (!currentNumber.isEmpty() && !operation.isEmpty()) {
                String finalResult;
                switch (operation) {
                    case "+":
                        result += Double.parseDouble(currentNumber);
                        history += " + " + currentNumber;
                        break;
                    case "-":
                        result -= Double.parseDouble(currentNumber);
                        history += " - " + currentNumber;
                        break;
                    case "*":
                        result *= Double.parseDouble(currentNumber);
                        history += " × " + currentNumber;
                        break;
                    case "/":
                        if (Double.parseDouble(currentNumber) != 0.0) {
                            result /= Double.parseDouble(currentNumber);
                            history += " ÷ " + currentNumber;
                        } else {
                            display.setText("Error");
                            currentNumber = "";
                            operation = "";
                            result = 0.0;
                            return;
                        }
                        break;
                }
                finalResult = result % 1.0 == 0.0 ? String.valueOf((int) result) : String.valueOf(result);
                history += " = " + finalResult + "\n";
                display.setText(finalResult);
                currentNumber = "";
                operation = "";
                result = 0.0;
            }
        });

        btnAC.setOnClickListener(v -> {
            currentNumber = "";
            result = 0.0;
            operation = "";
            display.setText("0");
        });

        btnDot.setOnClickListener(v -> {
            if (!currentNumber.contains(".")) {
                if (currentNumber.isEmpty()) {
                    currentNumber = "0.";
                } else {
                    currentNumber += ".";
                }
                display.setText(currentNumber);
            }
        });

        btnPlusMinus.setOnClickListener(v -> {
            if (!currentNumber.isEmpty() && !currentNumber.equals("0")) {
                if (currentNumber.startsWith("-")) {
                    currentNumber = currentNumber.substring(1);
                } else {
                    currentNumber = "-" + currentNumber;
                }
                display.setText(currentNumber);
            }
        });

        btnPercent.setOnClickListener(v -> {
            if (!currentNumber.isEmpty()) {
                try {
                    double num = Double.parseDouble(currentNumber);
                    double percentValue = num / 100;
                    currentNumber = String.valueOf(percentValue);
                    display.setText(currentNumber);
                } catch (Exception e) {
                    display.setText("Error");
                }
            }
        });

        btnH.setOnClickListener(v -> {
            if (history.isEmpty()) {
                display.setText("No History");
            } else {
                display.setText(history.trim());
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}